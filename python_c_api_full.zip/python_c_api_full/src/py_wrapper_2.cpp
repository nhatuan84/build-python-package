#include <Python.h>
#include <structmember.h>
#define NPY_NO_DEPRECATED_API NPY_1_7_API_VERSION
#include <numpy/arrayobject.h>

#include "enc_dec.h"

namespace 
{
    VidCapture vid_capture;
    VidWriter vid_writer;
}

static PyObject *vid_capture_init(PyObject *self, PyObject *args) {
    char *s;
    if (!PyArg_ParseTuple(args, "z", &s)) {
        return NULL;
    }
    if(s == NULL) {
        return PyUnicode_FromString("input is None");
    }
    vid_capture.init(std::string(s));
    return Py_BuildValue("i", 1);
}

static PyObject *vid_capture_is_opened(PyObject *self, PyObject *args) {
    if(vid_capture.isOpened())
    {
        return Py_BuildValue("i", 1);
    }
    return Py_BuildValue("i", 0);
}

static PyObject *vid_capture_close(PyObject *self, PyObject *args) {
    vid_capture.close();
    return Py_BuildValue("i", 1);
}

static PyObject *vid_capture_get_params(PyObject *self, PyObject *args) {
    int height;
    int width;
    int64_t bit_rate;
    int time_base_num;
    int time_base_den;
    int gop_size;
    int64_t duration;
    vid_capture.getParams(height, width, bit_rate, time_base_num, time_base_den, gop_size, duration);
    std::cout << height << " width " << width << " bit_rate " << bit_rate << 
        " time_base_num " << time_base_num << " time_base_den " << time_base_den << 
        " gop_size " << gop_size << " duration " << duration << "\n";
    PyObject *result = Py_BuildValue(   "{s:i,s:i,s:K,s:i,s:i,s:i}",
                                        "height", height, 
                                        "width", width,
                                        "bit_rate", bit_rate,
                                        "time_base_num", time_base_num,
                                        "time_base_den", time_base_den,
                                        "gop_size", gop_size);
    return result;
}

static PyObject *vid_capture_read(PyObject *self, PyObject *args) {
    int ignore_audio;
    PyArg_ParseTuple(args, "i", &ignore_audio);
    ReadFrame r = vid_capture.read(ignore_audio);
    if(r.end == false) {
        size_t len = r.mat.total() * r.mat.elemSize();
        uchar *buffer = new uchar[len];
        std::memcpy(buffer, r.mat.data, len);
        npy_intp dims[] = { r.mat.rows, r.mat.cols, r.mat.channels() };
        PyArrayObject* val4 = (PyArrayObject *)PyArray_SimpleNewFromData(sizeof(dims)/sizeof(npy_intp), dims, NPY_UINT8, (void*) buffer);
        PyArray_UpdateFlags((PyArrayObject *)val4, NPY_ARRAY_ALIGNED|NPY_ARRAY_CARRAY|NPY_ARRAY_OWNDATA);
        PyObject *result = Py_BuildValue(   "{s:i,s:K,s:i,s:N}",
                                "frame_cnt", r.frame_cnt, 
                                "pts", r.pts,
                                "end", r.end,
                                "frame", val4);
        return result;
    }
    PyObject *result = Py_BuildValue(   "{s:i}",
                                        "end", r.end);
    return result;
}

static PyObject *vid_capture_read_skip(PyObject *self, PyObject *args) {
    int ignore_audio;
    float expect_fps;
    PyArg_ParseTuple(args, "fi", &expect_fps, &ignore_audio);
    ReadFrame r = vid_capture.readSkip(expect_fps, ignore_audio);
    if(r.end == false){
        size_t len = r.mat.total() * r.mat.elemSize();
        uchar *buffer = new uchar[len];
        std::memcpy(buffer, r.mat.data, len);
        npy_intp dims[] = { r.mat.rows, r.mat.cols, r.mat.channels() };
        PyArrayObject* val4 = (PyArrayObject *)PyArray_SimpleNewFromData(sizeof(dims)/sizeof(npy_intp), dims, NPY_UINT8, (void*) buffer);
        PyArray_ENABLEFLAGS((PyArrayObject *)val4, NPY_ARRAY_ALIGNED|NPY_ARRAY_CARRAY|NPY_ARRAY_OWNDATA);
        PyObject *result = Py_BuildValue(   "{s:i,s:K,s:i,s:N}",
                                            "frame_cnt", r.frame_cnt, 
                                            "pts", r.pts,
                                            "end", r.end,
                                            "frame", val4);
        return result;
    }
    PyObject *result = Py_BuildValue(   "{s:i}",
                                        "end", r.end);
    return result;
}

static PyObject *vid_writer_init(PyObject *self, PyObject *args) {
    char *s;
    if (!PyArg_ParseTuple(args, "z", &s)) {
        return NULL;
    }
    if(s == NULL) {
        return PyUnicode_FromString("input is None");
    }
    vid_writer.init(std::string(s));
    return Py_BuildValue("i", 1);
}

static PyObject *vid_writer_is_ready(PyObject *self, PyObject *args) {
    if(vid_writer.isReady())
    {
        return Py_BuildValue("i", 1);
    }
    return Py_BuildValue("i", 0);
}

static PyObject *vid_writer_set_params(PyObject *self, PyObject *args) {
    int height;
    int width;
    int64_t bit_rate;
    int time_base_num;
    int time_base_den;
    int gop_size;
    int codec_id;
    PyArg_ParseTuple(args, "iiKiiii", &height, &width, &bit_rate, 
                            &time_base_num, &time_base_den, &gop_size, &codec_id);
    std::cout << height << " width " << width << " bit_rate " << bit_rate << 
        " time_base_num " << time_base_num << " time_base_den " << time_base_den << 
        " gop_size " << gop_size << " codec_id " << codec_id << "\n";
    vid_writer.setParams(height, width, bit_rate, time_base_num, time_base_den, gop_size, codec_id);
    return Py_BuildValue("i", 1);
}

static PyObject *vid_writer_write(PyObject *self, PyObject *args) {
    int frame_cnt ;
    int64_t pts;
    PyArrayObject *arrays;
    if (!PyArg_ParseTuple(args, "O!iK", &PyArray_Type, &arrays, &frame_cnt, &pts)) {
        return Py_BuildValue("i", 0);
    }
    int dim = PyArray_NDIM(arrays);
    if(dim > 0) {
        npy_intp *dims = PyArray_DIMS(arrays); 
        uchar* data = (uchar *)PyArray_DATA(arrays);
        cv::Mat mat(dims[0], dims[1], CV_8UC3, data);
        int ret = vid_writer.write(mat, frame_cnt, pts);
        if(ret < 0){
            return Py_BuildValue("i", 0);
        }
    }
    
    return Py_BuildValue("i", 1);
}

static PyObject *vid_writer_close(PyObject *self, PyObject *args) {
    vid_writer.close();
    return Py_BuildValue("i", 1);
}

static PyMethodDef enc_dec_methods[] = {
    //capture
    {"vid_capture_init", vid_capture_init, METH_VARARGS, "vid_capture_init"},
    {"vid_capture_is_opened", vid_capture_is_opened, METH_NOARGS, "vid_capture_is_opened"},
    {"vid_capture_get_params", vid_capture_get_params, METH_NOARGS, "vid_capture_get_params"},
    {"vid_capture_read", vid_capture_read, METH_VARARGS, "vid_capture_read"},
    {"vid_capture_read_skip", vid_capture_read_skip, METH_VARARGS, "vid_capture_read_skip"},
    {"vid_capture_close", vid_capture_close, METH_NOARGS, "vid_capture_close"},
    //writer
    {"vid_writer_init", vid_writer_init, METH_VARARGS, "vid_writer_init"},
    {"vid_writer_set_params", vid_writer_set_params, METH_VARARGS, "vid_writer_set_params"},
    {"vid_writer_is_ready", vid_writer_is_ready, METH_NOARGS, "vid_writer_is_ready"},
    {"vid_writer_write", vid_writer_write, METH_VARARGS, "vid_writer_write"},
    {"vid_writer_close", vid_writer_close, METH_NOARGS, "vid_writer_close"},
    {NULL}//NULL terminates array of PyMethodDef
};

static struct PyModuleDef enc_dec_definition = {
    PyModuleDef_HEAD_INIT,
    "enc_dec",//module name
    "enc/dec api", //doc string
    -1,
    enc_dec_methods
};

PyMODINIT_FUNC PyInit_enc_dec(void) {
    Py_Initialize();
    import_array();
    PyObject *m = PyModule_Create(&enc_dec_definition);
    
    return m;
}