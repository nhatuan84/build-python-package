import obj


x = obj.Foo("abc", "def")
obj.Print(x)