import obj


x = obj.Foo("abc", "def")
x.Print()