extern "C" {
#include <libavutil/imgutils.h>
#include <libavutil/samplefmt.h>
#include <libavutil/timestamp.h>
#include <libavcodec/avcodec.h>
#include <libavcodec/packet.h>
#include <libavformat/avformat.h>
#include <libswscale/swscale.h>
#include <libavfilter/avfilter.h>
#include <libavdevice/avdevice.h>
#include <libswresample/swresample.h>
#include <libavutil/time.h>
}
#include <iostream>
#include <string>
#include <vector>
#include <queue>
#include <tuple>
#include <mutex>
#include <opencv2/opencv.hpp>

//ffplay -f f32le -ar 44100 -ac 1 audio.raw
//codec id: https://libav.org/documentation/doxygen/master/avcodec_8h_source.html

typedef struct 
{
    int frame_cnt;
    int end;
    int64_t pts;
    cv::Mat mat;
} ReadFrame;

class VidCapture 
{
public:
    VidCapture(std::string file_name)
    {
        init(file_name);
    }
    VidCapture(){}
    void init(std::string file_name, std::string audio_file_name="audio.raw")
    {
        if(m_opened == false)
        {
            m_fileName = file_name;
            m_opened = false;
            m_frameCounter = 0;
            m_fmtCtx = NULL;
            m_videoDecCtx = NULL;
            m_audioDecCtx = NULL;
            m_videoStreamIdx = -1;
            m_audioStreamIdx = -1;
            m_frame = NULL;
            m_pkt = NULL; 
            m_frameCounter = 0;
            m_nextFrameTs = 0.0f;
            m_audioDstFile = fopen(audio_file_name.c_str(), "wb"); 
            if(prepare() == 0)
            {
                m_opened = true;
            }
        }
    }
    ~VidCapture()
    {
        close();
    }
    void close()
    {
        if(m_opened)
        {
            if (m_videoDecCtx)
            {
                avcodec_free_context(&m_videoDecCtx);
            } 
            if (m_audioDecCtx)
            {
                avcodec_free_context(&m_audioDecCtx);
            }
            if (m_fmtCtx)
            {
                avformat_close_input(&m_fmtCtx);
            }
            if (m_pkt)
            {
                av_packet_free(&m_pkt);
            }
            if (m_frame)
            {
                av_frame_free(&m_frame);
            }
            if(m_audioFrame)
            {
                av_frame_free(&m_audioFrame);
            }
            if(m_swr)
            {
                swr_free(&m_swr); 
            }
            if(m_audioDstFile)
            {
                fclose(m_audioDstFile);
            }
        }
        m_opened = false;
    }
    void getParams(int &height, int &width, int64_t &bit_rate, int &time_base_num, 
                    int &time_base_den, int &gop_size, int64_t &duration);
    bool isOpened();
    ReadFrame read(int ignore_audio=1); 
    ReadFrame readSkip(float expect_fps, int ignore_audio=1);

private:
    FILE *m_audioDstFile = NULL;
    std::string m_fileName;
    float m_nextFrameTs;
    float m_fps;
    bool m_opened;
    AVFormatContext *m_fmtCtx;
    AVCodecContext  *m_videoDecCtx;
    AVCodecContext  *m_audioDecCtx;
    int m_videoStreamIdx;
    int m_audioStreamIdx;
    AVFrame     *m_frame;
    AVPacket    *m_pkt;
    int m_frameCounter;
    std::mutex m_mutex;
    int m_audioNChannels;
    int m_audioSampleRate;
    int m_audioNSamples;
    SwrContext *m_swr;
    AVFrame *m_audioFrame;

    int prepare();
    int openCodecContext(int *stream_idx, AVCodecContext **dec_ctx, 
                        AVFormatContext *fmt_ctx, enum AVMediaType type);

    int decodePacket(AVCodecContext *dec, ReadFrame &result);

    cv::Mat convertAVToCV(const AVFrame *frame);
    int writeAudioFile(AVFrame *frame, int data_size, int channels);
    int getFormatFromSampleFmt(const char **fmt,
                                      enum AVSampleFormat sample_fmt);
};

typedef struct {
    AVStream *st;
    AVCodecContext *enc;
    int64_t next_pts;
    int samples_count;
    const AVCodec *codec;
    AVFrame *frame;
    AVFrame *tmp_frame;
    AVPacket *tmp_pkt;
    float t, tincr, tincr2;
    struct SwsContext *sws_ctx;
    struct SwrContext *swr_ctx;
} OutputStream;

class VidWriter
{
public:
    VidWriter(std::string filename)
    {
        init(filename);
    }
    VidWriter(){}
    void init(std::string filename)
    {
        if(m_ready == false)
        {
            m_filename = filename;
        }
    }
    ~VidWriter()
    {
        close();
    }
    void close()
    {
        if(m_ready)
        {
            if(m_fmtCtx)
            {
                av_write_trailer(m_fmtCtx);
            }
            if(m_audioSwr)
            {
                swr_free(&m_audioSwr); 
            }
            if(m_videoFrame)
            {
                av_frame_free(&m_videoFrame);
            }
            if(m_pkt)
            {
                av_packet_free(&m_pkt);
            }
            if(m_codecCxt)
            {
                avcodec_free_context(&m_codecCxt);
            }
            if (!(m_fmtCtx->flags & AVFMT_NOFILE))
            {
                avio_closep(&m_fmtCtx->pb);
            }
            if(m_fmtCtx)
            {
                avformat_free_context(m_fmtCtx); 
            }    
        } 
        m_ready = false;
    }
    
    void setParams(int height, int width, int64_t bit_rate=400000, int time_base_num=1, 
                    int time_base_den=25, int gop_size=12, int codec_id=0)
    {
        m_ready = false;
        m_height = height;
        m_width = width;
        m_bitRate = bit_rate;
        m_timeBaseNum = time_base_num;
        m_timeBaseDen = time_base_den;
        m_gopSize = gop_size;
        m_codecId = codec_id;
        if(prepare() == 0)
        {
            m_ready = true;
        }
    }
    bool isReady()
    {
        return m_ready;
    }
    int write(cv::Mat &mat, int frame_cnt, int64_t pts);
private:
    std::string m_filename;
    int m_height;
    int m_width;
    int64_t m_bitRate;
    int m_timeBaseNum;
    int m_timeBaseDen;
    int m_gopSize;
    int m_codecId;
    bool m_ready;
    cv::Mat m_preMat;
    AVFormatContext *m_fmtCtx;
    const AVOutputFormat *m_fmtOutput;
    const AVCodec *m_videoCodec;
    const AVCodec *m_audioCodec;
    AVFrame  *m_videoFrame;
    AVFrame  *m_audioFrame;
    AVPacket *m_pkt;
    AVStream *m_videoStream;
    AVStream *m_audioStream;
    AVCodecContext *m_videoCodecCxt;
    AVCodecContext *m_audioCodecCxt;
    SwrContext *m_audioSwr;

    int addStream(const AVCodec **codec, enum AVCodecID codec_id);
    AVFrame *allocPicture(enum AVPixelFormat pix_fmt, int width, int height);
    int openVideo(AVDictionary *opt_arg);
    int openAudio(AVDictionary *opt_arg);
    int prepare();
    int convertCVToAV(cv::Mat &image);
    
};