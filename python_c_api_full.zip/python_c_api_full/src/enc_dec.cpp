#include "enc_dec.h"

bool VidCapture::isOpened()
{
    return m_opened;
}

void VidCapture::getParams(int &height, int &width, int64_t &bit_rate, int &time_base_num, 
                    int &time_base_den, int &gop_size, int64_t &duration)
{
    height = m_videoDecCtx->height;
    width = m_videoDecCtx->width;
    bit_rate = m_videoDecCtx->bit_rate;
    time_base_num = m_fmtCtx->streams[m_videoStreamIdx]->time_base.num;
    time_base_den = m_fmtCtx->streams[m_videoStreamIdx]->time_base.den;
    gop_size = m_videoDecCtx->gop_size;
    duration = m_fmtCtx->duration;
}

int VidCapture::decodePacket(AVCodecContext *dec, ReadFrame &result)
{
    int ret = 0;
    int ret_func = 0;
    ret = avcodec_send_packet(dec, m_pkt);
    if (ret < 0) {
        std::cout << "error submitting a packet for decoding\n";
        return -1;
    }
    while (ret >= 0) 
    { 
        ret = avcodec_receive_frame(dec, m_frame);
        if (ret < 0) 
        {   
            if (ret == AVERROR_EOF || ret == AVERROR(EAGAIN))
            {
                return -1;
            }
            std::cout << "error during decoding\n";
            return -1;
        }
        if (dec->codec->type == AVMEDIA_TYPE_VIDEO)
        {
            int pts = m_frame->pts;
            result.pts = pts;
            result.end = false;
            result.mat = convertAVToCV(m_frame); 
            ret_func = 1;
        }
        else
        {
            int data_size = av_get_bytes_per_sample(dec->sample_fmt);
            if (data_size < 0) 
            {
                /* This should not occur, checking just for paranoia */
                std::cout << "Failed to calculate data size\n";
            }
            writeAudioFile(m_frame, data_size, dec->channels);
            ret_func = 1;
        }
        av_frame_unref(m_frame);
        return ret_func;
    }
    return ret_func;
}

ReadFrame VidCapture::read(int ignore_audio)
{
    int ret = -1;
    ReadFrame result;
    if(m_opened)
    {
        while(ret < 0)
        {
            if (av_read_frame(m_fmtCtx, m_pkt) >= 0) 
            {
                if (m_pkt->stream_index == m_videoStreamIdx)
                {
                    ret = decodePacket(m_videoDecCtx, result);
                    if(ret == 1)
                    {
                        result.frame_cnt = m_frameCounter;
                        m_frameCounter ++;
                    }
                }
                else if (m_pkt->stream_index == m_audioStreamIdx)
                {
                    if(!ignore_audio){
                        decodePacket(m_audioDecCtx, result);
                        ret = -1;
                    }
                }
                av_packet_unref(m_pkt);
            }
            else
            {
                result.end = true;
                break;
            }
        }
    }
    else
    {
        result.end = true;
        std::cout << "VidCapture is not ready\n";
    }
    return result;      
}

ReadFrame VidCapture::readSkip(float expect_fps, int ignore_audio)
{
    ReadFrame frame;
    if(expect_fps > m_fps)
    {
        std::cout << "invalid expected fps\n";
        frame.end = true;
    }
    else
    {
        while (true)
        {
            frame = read(ignore_audio);
            if(frame.end == false)
            {
                float framets = frame.frame_cnt * (1.0f / m_fps);
                if (framets >= m_nextFrameTs)
                {
                    m_nextFrameTs += (1.0f / expect_fps);
                    break;
                }
            }
            else
            {
                break;
            }
        }
    }
    return frame;
}

int VidCapture::getFormatFromSampleFmt(const char **fmt,
                                      enum AVSampleFormat sample_fmt)
{
    int i;
    struct sample_fmt_entry {
        enum AVSampleFormat sample_fmt; const char *fmt_be, *fmt_le;
    } sample_fmt_entries[] = {
        { AV_SAMPLE_FMT_U8,  "u8",    "u8"    },
        { AV_SAMPLE_FMT_S16, "s16be", "s16le" },
        { AV_SAMPLE_FMT_S32, "s32be", "s32le" },
        { AV_SAMPLE_FMT_FLT, "f32be", "f32le" },
        { AV_SAMPLE_FMT_DBL, "f64be", "f64le" },
        { AV_SAMPLE_FMT_FLTP, "f32be", "f32le"},
    };
    *fmt = NULL;

    for (i = 0; i < FF_ARRAY_ELEMS(sample_fmt_entries); i++) {
        struct sample_fmt_entry *entry = &sample_fmt_entries[i];
        if (sample_fmt == entry->sample_fmt) {
            *fmt = AV_NE(entry->fmt_be, entry->fmt_le);
            return 0;
        }
    }

    fprintf(stderr,
            "sample format %s is not supported as output format\n",
            av_get_sample_fmt_name(sample_fmt));
    return -1;
}

int VidCapture::prepare()
{
    int ret = 0;

    if(avformat_open_input(&m_fmtCtx, m_fileName.c_str(), NULL, NULL) != 0)
    {
        std::cout << "error open file\n";
        return -1;
    }

    if (avformat_find_stream_info(m_fmtCtx, NULL) < 0) 
    {
        std::cout << "error get stream information\n";
        return -1;
    }

    if (openCodecContext(&m_videoStreamIdx, &m_videoDecCtx, m_fmtCtx, AVMEDIA_TYPE_VIDEO) >= 0) 
    {
        m_fps = av_q2d(m_fmtCtx->streams[m_videoStreamIdx]->avg_frame_rate);
    }
    if (openCodecContext(&m_audioStreamIdx, &m_audioDecCtx, m_fmtCtx, AVMEDIA_TYPE_AUDIO) >= 0) 
    {
        const char *fmt;
        m_audioNChannels = m_audioDecCtx->channels;
        m_audioSampleRate = m_audioDecCtx->sample_rate;
        getFormatFromSampleFmt(&fmt, m_audioDecCtx->sample_fmt);
        printf("Play the output audio file with the command:\n"
           "ffplay -f %s -ac %d -ar %d audio.raw\n",
           fmt, m_audioNChannels, m_audioSampleRate);
        m_audioFrame = av_frame_alloc();
        m_swr = swr_alloc_set_opts(NULL, 
                                   m_audioDecCtx->channel_layout,
                                   AV_SAMPLE_FMT_S16,
                                   m_audioSampleRate,
                                   m_audioDecCtx->channel_layout,
                                   m_audioDecCtx->sample_fmt,
                                   m_audioDecCtx->sample_rate,
                                   0, 
                                   NULL);
        std::cout << "xxxx " << m_audioDecCtx->sample_rate << " " << m_audioDecCtx->bit_rate << "\n";
        swr_init(m_swr);
        m_audioFrame->format = static_cast<AVSampleFormat>(AV_SAMPLE_FMT_S16);
        m_audioFrame->channel_layout = m_audioDecCtx->channel_layout;
        m_audioFrame->sample_rate = m_audioSampleRate;
    }
    if(m_videoStreamIdx == -1 || m_audioStreamIdx == -1)
    {
        std::cout << "could not find audio or video stream in the input\n";
        return -1;
    }
    
    m_frame = av_frame_alloc();
    if (!m_frame) 
    {
        std::cout << "error allocate frame\n";
        return -1;
    }
    m_pkt = av_packet_alloc();
    if (!m_pkt) 
    {
        std::cout << "error allocate packet\n";
        return -1;
    }
    return 0;
}

int VidCapture::openCodecContext(int *stream_idx, AVCodecContext **dec_ctx, 
                    AVFormatContext *fmt_ctx, enum AVMediaType type)
{
    int stream_index;
    AVStream *st;
    const AVCodec *dec = NULL;
    int ret = 0;

    ret = av_find_best_stream(fmt_ctx, type, -1, -1, NULL, 0);
    if (ret < 0) 
    {
        std::cout << "error could not find stream in input file \n";
        return ret;
    } 
    else 
    {
        stream_index = ret;
        st = fmt_ctx->streams[stream_index];

        dec = avcodec_find_decoder(st->codecpar->codec_id);
        if (!dec) 
        {
            std::cout << "error to find codec\n";
            return -1;
        }
        *dec_ctx = avcodec_alloc_context3(dec);
        if (!*dec_ctx) 
        {
            std::cout << "error to allocate the codec context\n";
            return -1;
        }

        if ((ret = avcodec_parameters_to_context(*dec_ctx, st->codecpar)) < 0) 
        {
            std::cout << "error to copy codec parameters to decoder context\n";
            return -1;
        }

        if ((ret = avcodec_open2(*dec_ctx, dec, NULL)) < 0) 
        {        
            std::cout << "error to open codec\n";
            return -1;
        }
        *stream_idx = stream_index;
    }
    return 0;
}

cv::Mat VidCapture::convertAVToCV(const AVFrame *frame) 
{
    int width = frame->width;
    int height = frame->height;
    cv::Mat image(height, width, CV_8UC3);
    int cvLinesizes[1];
    cvLinesizes[0] = image.step1();

    SwsContext *conversion = sws_getContext(
        width, height, AV_PIX_FMT_YUV420P, width, height,
        AV_PIX_FMT_BGR24, SWS_FAST_BILINEAR, NULL, NULL, NULL);
    sws_scale(conversion, frame->data, frame->linesize, 0, height, &image.data,
            cvLinesizes);
    sws_freeContext(conversion);

    return image;
}

int VidCapture::writeAudioFile(AVFrame *frame, int data_size, int channels)
{
#if 1
    int dst_samples = frame->channels * av_rescale_rnd(
                                   swr_get_delay(m_swr, frame->sample_rate)
                                   + frame->nb_samples,
                                   m_audioSampleRate,
                                   frame->sample_rate,               
                                   AV_ROUND_UP);
    uint8_t *audiobuf = NULL;
    m_audioFrame->nb_samples = frame->nb_samples;
    av_samples_alloc(&audiobuf, NULL, channels, dst_samples, AV_SAMPLE_FMT_S16, 1);
    dst_samples = frame->channels * swr_convert(m_swr, &audiobuf, dst_samples,
                                            (const uint8_t**) frame->data, frame->nb_samples);
    if (dst_samples < 0) {
        std::cout << "error while converting\n";
        return -1;
    }
    av_samples_fill_arrays(m_audioFrame->data, m_audioFrame->linesize, audiobuf,
                                        frame->channels, frame->nb_samples, AV_SAMPLE_FMT_S16, 1);
    fwrite(m_audioFrame->data[0], 1, m_audioFrame->linesize[0], m_audioDstFile);
    av_freep(&audiobuf); 
    
    return 0;
#else
    for (int i = 0; i < frame->nb_samples; i++)
    {
        for (int ch = 0; ch < channels; ch++)
        {
            fwrite(frame->data[ch] + data_size*i, 1, data_size, m_audioDstFile);
        }
    }
#endif
    return 0;
}

int VidWriter::addStream(const AVCodec **codec, enum AVCodecID codec_id)
{
    AVCodecContext *c;

    /* find the encoder */
    *codec = avcodec_find_encoder(codec_id);
    if (!(*codec)) 
    {
        std::cout << "Could not find encoder for " << avcodec_get_name(codec_id) << "\n";
        return -1;
    }
    m_pkt = av_packet_alloc();
    if (!m_pkt) 
    {
        std::cout << "Could not allocate AVPacket\n";
        return -1;
    }
    m_stream = avformat_new_stream(m_fmtCtx, NULL);
    if (!m_stream) 
    {
        std::cout << "Could not allocate stream\n";
        return -1;
    }
    m_stream->id = m_fmtCtx->nb_streams - 1;
    c = avcodec_alloc_context3(*codec);
    if (!c) 
    {
        std::cout << "Could not alloc an encoding context\n";
        return -1;
    }
    m_codecCxt = c;

    switch ((*codec)->type) 
    {
    case AVMEDIA_TYPE_AUDIO:
        c->sample_fmt  = (*codec)->sample_fmts ?
            (*codec)->sample_fmts[0] : AV_SAMPLE_FMT_FLTP;
        c->bit_rate    = 127999;
        c->sample_rate = 44100;
        if ((*codec)->supported_samplerates) 
        {
            c->sample_rate = (*codec)->supported_samplerates[0];
            for (int i = 0; (*codec)->supported_samplerates[i]; i++) 
            {
                if ((*codec)->supported_samplerates[i] == 44100)
                {
                    c->sample_rate = 44100;
                }
            }
        }
        c->channels = av_get_channel_layout_nb_channels(c->channel_layout);
        c->channel_layout = AV_CH_LAYOUT_STEREO;
        if ((*codec)->channel_layouts) 
        {
            c->channel_layout = (*codec)->channel_layouts[0];
            for (int i = 0; (*codec)->channel_layouts[i]; i++) 
            {
                if ((*codec)->channel_layouts[i] == AV_CH_LAYOUT_STEREO)
                {
                    c->channel_layout = AV_CH_LAYOUT_STEREO;
                }
            }
        }
        c->channels        = av_get_channel_layout_nb_channels(c->channel_layout);
        m_stream->time_base = (AVRational){ 1, c->sample_rate };
        break;

    case AVMEDIA_TYPE_VIDEO:
        c->codec_id = codec_id;
        //bit_rate value decides quality of output
        c->bit_rate = m_bitRate;
        c->width    = m_width;
        c->height   = m_height;
        m_stream->time_base = (AVRational){ m_timeBaseNum, m_timeBaseDen };
        c->time_base       = m_stream->time_base;
        c->gop_size      = m_gopSize; 
        c->pix_fmt       = AV_PIX_FMT_YUV420P;
        break;
    default:
        break;
    }

    /* Some formats want stream headers to be separate. */
    if (m_fmtCtx->oformat->flags & AVFMT_GLOBALHEADER)
    {
        c->flags |= AV_CODEC_FLAG_GLOBAL_HEADER;
    }
}

AVFrame *VidWriter::allocPicture(enum AVPixelFormat pix_fmt, int width, int height)
{
    AVFrame *picture;
    int ret;

    picture = av_frame_alloc();
    if (!picture)
    {
        return NULL;
    }
    picture->format = pix_fmt;
    picture->width  = width;
    picture->height = height;

    /* allocate the buffers for the frame data */
    ret = av_frame_get_buffer(picture, 0);
    if (ret < 0) {
        std::cout << "Could not allocate frame data.\n";
        return NULL;
    }
    return picture;
}

int VidWriter::openVideo(AVDictionary *opt_arg)
{
    int ret;
    AVCodecContext *c = m_codecCxt;
    AVDictionary *opt = NULL;

    av_dict_copy(&opt, opt_arg, 0);

    /* open the codec */
    ret = avcodec_open2(c, m_videoCodec, &opt);
    av_dict_free(&opt);

    if (ret < 0) 
    {
        std::cout << "Could not open video codec\n";
        return -1;
    }
    /* allocate and init a re-usable frame */
    m_videoFrame = allocPicture(c->pix_fmt, c->width, c->height);
    if (!m_videoFrame) {
        std::cout << "Could not allocate video frame\n";
        return -1;
    }

    /* copy the stream parameters to the muxer */
    ret = avcodec_parameters_from_context(m_stream->codecpar, c);
    if (ret < 0) {
        std::cout << "Could not copy the stream parameters\n";
        return -1;
    }
}

int VidWriter::openAudio(AVDictionary *opt_arg)
{
    AVCodecContext *c = m_codecCxt;
    int nb_samples;
    int ret;
    AVDictionary *opt = NULL;

    /* open it */
    av_dict_copy(&opt, opt_arg, 0);
    ret = avcodec_open2(c, m_audioCodec, &opt);
    av_dict_free(&opt);
    if (ret < 0) 
    {
        std::cout << "Could not open audio codec\n";
        return -1;
    }

    /* copy the stream parameters to the muxer */
    ret = avcodec_parameters_from_context(m_stream->codecpar, c);
    if (ret < 0) 
    {
        std::cout << "Could not copy the stream parameters\n";
        return -1;
    }

    m_audioSwr = swr_alloc();
    if (!m_audioSwr) 
    {
        std::cout << "Could not allocate audio resampler\n";
        return -1;
    }

    /* set options */
    av_opt_set_int       (m_audioSwr, "in_channel_count",   c->channels,       0);
    av_opt_set_int       (m_audioSwr, "in_sample_rate",     c->sample_rate,    0);
    av_opt_set_sample_fmt(m_audioSwr, "in_sample_fmt",      AV_SAMPLE_FMT_S16, 0);
    av_opt_set_int       (m_audioSwr, "out_channel_count",  c->channels,       0);
    av_opt_set_int       (m_audioSwr, "out_sample_rate",    c->sample_rate,    0);
    av_opt_set_sample_fmt(m_audioSwr, "out_sample_fmt",     c->sample_fmt,     0);

    /* initialize the resampling context */
    if ((ret = swr_init(m_audioSwr)) < 0) 
    {
        std::cout << "Failed to initialize the resampling context\n";
        return -1;
    }
    return 0;
}

int VidWriter::prepare()
{
    int ret = -1;
    int have_video = 0;
    int have_audio = 0;
    int encode_video = 0;
    int encode_audio = 0;
    AVDictionary *opt = NULL;

    avformat_alloc_output_context2(&m_fmtCtx, NULL, NULL, m_filename.c_str());
    if (!m_fmtCtx) {
        std::cout << "Could not deduce output format from file extension\n";
        return -1;
    }

    m_fmtOutput = m_fmtCtx->oformat;

    if (m_fmtOutput->video_codec != AV_CODEC_ID_NONE) 
    {
        if(m_codecId > 0)
        {
            addStream(&m_videoCodec, static_cast<AVCodecID>(m_codecId));
        }
        else
        {
            addStream(&m_videoCodec, m_fmtOutput->video_codec);
        }
        have_video = 1;
        encode_video = 1;
    }
    
    if (m_fmtOutput->audio_codec != AV_CODEC_ID_NONE) 
    {
        addStream(&m_audioCodec, m_fmtOutput->audio_codec);
        have_audio = 1;
        encode_audio = 1;
    }

    if (have_video)
    {
        openVideo(opt);
    }
    if (have_audio)
    {
        openAudio(opt);
    }
    av_dump_format(m_fmtCtx, 0, m_filename.c_str(), 1);

    if (!(m_fmtOutput->flags & AVFMT_NOFILE)) 
    {
        ret = avio_open(&m_fmtCtx->pb, m_filename.c_str(), AVIO_FLAG_WRITE);
        if (ret < 0) 
        {
            std::cout << "Could not open " << m_filename << "\n";
            return -1;
        }
    }
    /* Write the stream header */
    ret = avformat_write_header(m_fmtCtx, NULL);
    
    if (ret < 0) {
        std::cout << "Error occurred when opening output file\n";
        return -1;
    }
    return 0;
}
int VidWriter::convertCVToAV(cv::Mat &image) 
{
    int width = image.cols;
    int height = image.rows;
    int cvLinesizes[1];
    cvLinesizes[0] = image.step1();

    SwsContext *conversion = sws_getContext(
        width, height, AV_PIX_FMT_BGR24, width, height,
        AV_PIX_FMT_YUV420P, SWS_FAST_BILINEAR, NULL, NULL, NULL);
    sws_scale(conversion, &image.data, cvLinesizes, 0, height, m_videoFrame->data, m_videoFrame->linesize);
    sws_freeContext(conversion);
    
    return 0;
}

int VidWriter::write(cv::Mat &mat, int frame_cnt, int64_t pts)
{
    int ret;
    if(!m_ready)
    {
        std::cout << "VidWriter is not ready\n";
        return -1;
    }
    if(frame_cnt > 0)
    {
        /* avoid data copying */
        if (av_frame_make_writable(m_videoFrame) < 0)
        {
            std::cout << "error to make frame writable\n";
            return -1;
        }
        m_videoFrame->pts = (frame_cnt-1) * (pts/frame_cnt);
        convertCVToAV(m_preMat);
        
        m_preMat = mat.clone();

        ret = avcodec_send_frame(m_codecCxt, m_videoFrame);
        if (ret < 0) 
        {
            std::cout << "Error sending a frame to the encoder\n";
            return -1;
        }
        while (ret >= 0) 
        {
            ret = avcodec_receive_packet(m_codecCxt, m_pkt);
            if (ret == AVERROR(EAGAIN) || ret == AVERROR_EOF)
            {
                break;
            }
            else if (ret < 0) 
            {
                std::cout << "Error encoding a frame\n";
                return -1;
            }

            /* rescale output packet timestamp values from codec to stream timebase */
            av_packet_rescale_ts(m_pkt, m_codecCxt->time_base, m_stream->time_base);
            m_pkt->stream_index = m_stream->index;
            ret = av_interleaved_write_frame(m_fmtCtx, m_pkt);
            /* pkt is now blank (av_interleaved_write_frame() takes ownership of
            * its contents and resets pkt), so that no unreferencing is necessary.
            * This would be different if one used av_write_frame(). */
            if (ret < 0) 
            {
                std::cout << "Error while writing output packet\n";
                return -1;
            }
        }
        return ret == AVERROR_EOF ? 1 : 0;
    }
    else
    {
        m_preMat = mat.clone();
    }
    return 0;
}

#ifndef BUILD_PY_WRAPPER
int main()
{
    //while(1)
    {
        VidCapture cap("/home/tuan/1.PROJECTS/zia-safe/ffmpeg/study/doremon.mp4");
        std::cout << "opened: " << cap.isOpened() << "\n";
        int height;
        int width;
        int64_t bit_rate;
        int time_base_num;
        int time_base_den;
        int gop_size;
        int64_t duration;

        cap.getParams(height, width, bit_rate, time_base_num, time_base_den, gop_size, duration);
        std::cout << height << " width " << width << " bit_rate " << bit_rate << 
            " time_base_num " << time_base_num << " time_base_den " << time_base_den << 
            " gop_size " << gop_size << " duration " << duration << "\n";

        VidWriter writer("output.mp4");
        writer.setParams(height, width, bit_rate, time_base_num, time_base_den, gop_size);
        std::cout << "ready: " << writer.isReady() << "\n";

        while(true)
        {
            //ReadFrame r = cap.readSkip(5.0f);
            ReadFrame r = cap.read(0);
            if(r.end == false)
            {
                cv::imshow("r", r.mat);
                cv::waitKey(1);
                writer.write(r.mat, r.frame_cnt, r.pts);
            }
            else
            {
                break;
            }
        }
        std::cout << "end\n";
    }
    return 0;
}
#endif