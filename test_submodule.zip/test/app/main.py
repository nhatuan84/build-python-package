from app.call import *

if __name__ == '__main__':
    call_them()