def print2():
    print("core2")