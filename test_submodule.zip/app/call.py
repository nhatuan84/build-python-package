from app.core1 import *
from app.core2 import *

def call_them():
    print1()
    print2()
