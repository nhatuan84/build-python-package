def call_from_core2():
    print('i am from core 1')
    
def print1():
    print("core1")