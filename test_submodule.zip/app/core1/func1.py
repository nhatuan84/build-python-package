def print1():
    print("core1")