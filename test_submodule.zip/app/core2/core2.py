from app.core1 import *

def print2():
    call_from_core2()
    print("core2")